#pragma once
#include "animal.h"
#include <string>

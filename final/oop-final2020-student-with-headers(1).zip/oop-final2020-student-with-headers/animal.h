#pragma once
#include <iostream>
#include <string>
#include "myDynamicArray.h"

#include "leg.h"

using namespace std;

#include "dog.h"
#include <iostream>
using namespace std;




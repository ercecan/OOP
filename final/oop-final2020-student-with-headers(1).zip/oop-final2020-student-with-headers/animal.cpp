#include "animal.h"
#include "myDynamicArray.cpp"
#include <iostream>

using namespace std;


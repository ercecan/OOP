
You are provided 3 main functions (q1.cpp, q2.cpp, q3.cpp), one for each question, to test your implementations.

See txt files (q1_output.txt, q2_output.txt, q3_output.txt) for corresponding expected outputs.


You can use following commands to compile and run the code

Question 1:
g++ q1.cpp myDynamicArray.cpp -o q1
./q1


Question 2:
g++ q2.cpp myDynamicArray.cpp animal.cpp dog.cpp cat.cpp bird.cpp -o q2
./q2


Question 3:
g++ q3.cpp myDynamicArray.cpp animal.cpp dog.cpp cat.cpp bird.cpp leg.cpp -o q3
./q3
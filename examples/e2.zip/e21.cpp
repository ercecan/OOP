// e21.cpp
// http://www.buzluca.info/oop
// using the cout object

#include<iostream>		// Header file for the cout object

int main() {
   int i=5;				// integer i is defined, initial value is 5
   float f=4.6;			// floating point number f is defined, initial value 4.6
   std::cout << "Integer Number = " << i << " Real Number = " << f;
   return 0;
}
